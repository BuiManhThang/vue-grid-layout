# 11 - 拖动栅格元素绑定到容器

可以获得栅格元素的坐标与容器间的绑定关系。

[查看资料](https://github.com/jbaysolutions/vue-grid-layout/blob/master/website/docs/.vuepress/components/Example11Bounded.vue)

<ClientOnly>
<Example11Bounded></Example11Bounded>
</ClientOnly>
