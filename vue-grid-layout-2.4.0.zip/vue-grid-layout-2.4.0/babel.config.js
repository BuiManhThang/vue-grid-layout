module.exports = {
    presets: [
        '@vue/app',
        '@babel/preset-env'
    ],
    "plugins": [
        "transform-flow-comments"
    ]
}
