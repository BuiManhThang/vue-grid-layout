# vue-grid-layout


https://github.com/wearebraid/vueformulate.com/tree/master/docs


# emit responsiveLayoutUpdatedEvent?

https://github.com/jbaysolutions/vue-grid-layout/compare/master...wzquyin:master
