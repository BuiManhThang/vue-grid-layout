# 10 - 从外面拖动

该演示演示了从栅格外部添加部件时发生的情况。
<br/>
将部件放到栅格中后，您将获得其坐标/属性，并可以据此执行操作。

[查看资料](https://github.com/jbaysolutions/vue-grid-layout/blob/master/website/docs/.vuepress/components/Example10DragFromOutside.vue)

<ClientOnly>
<Example10DragFromOutside></Example10DragFromOutside>
</ClientOnly>
