# 10 - Drag From Outside 

This demo shows what happens when an item is added from outside of the grid.
<br/>
Once you drop the item within the grid you'll get its coordinates/properties and can perform actions with it accordingly.

[View source](https://github.com/jbaysolutions/vue-grid-layout/blob/master/website/docs/.vuepress/components/Example10DragFromOutside.vue)

<ClientOnly>
<Example10DragFromOutside></Example10DragFromOutside>
</ClientOnly>
