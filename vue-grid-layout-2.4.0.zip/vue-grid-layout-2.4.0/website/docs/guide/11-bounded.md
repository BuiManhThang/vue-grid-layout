# 11 - Dragging grid items bounded to grid container

[View source](https://github.com/jbaysolutions/vue-grid-layout/blob/master/website/docs/.vuepress/components/Example11Bounded.vue)

<ClientOnly>
<Example11Bounded></Example11Bounded>
</ClientOnly>
